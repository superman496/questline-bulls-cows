
"""QuestLine Bulls & Cows Solver

A narrative-driven solver for 4-digit Bulls & Cows with non-repeating digits.

QuestLine follows strong world lines, bull pressure, cow-to-bull rotation,
low-signal fallback, and exact endgame compression.

Performance note
----------------
QuestLine uses a feedback matrix for speed. The matrix is expensive to build but
small enough to cache as a binary file. The first run creates:

    .questline_cache/feedback_matrix_v1.bin

Later runs load that cache, so startup is much faster.

Feedback format
---------------
Internally QuestLine uses "1b2c" style feedback, but the parser also accepts
"1a2b", "1,2", and "12" for convenience.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations, permutations
from pathlib import Path
import argparse
import os
import re
import time
from typing import DefaultDict, Dict, Iterable, List, Optional, Sequence, Tuple, Union

Digit = str
Code = str
Feedback = Tuple[int, int]
History = Sequence[Tuple[Code, Union[Feedback, str]]]

DIGITS = "0123456789"
CODE_LEN = 4
ALL_CODES: List[Code] = ["".join(p) for p in permutations(DIGITS, CODE_LEN)]
CODE_TO_INDEX: Dict[Code, int] = {code: i for i, code in enumerate(ALL_CODES)}
ALL_INDEXES: Tuple[int, ...] = tuple(range(len(ALL_CODES)))

FIXED_GROUPS: Dict[str, set[str]] = {
    "01": set("01"),
    "23": set("23"),
    "45": set("45"),
    "67": set("67"),
    "89": set("89"),
}
GROUP_ORDER: Tuple[str, ...] = tuple(FIXED_GROUPS)

FB_TO_BYTE: Dict[Feedback, int] = {(b, c): b * 5 + c for b in range(5) for c in range(5 - b)}
BYTE_TO_FB: Dict[int, Feedback] = {v: k for k, v in FB_TO_BYTE.items()}

OPENING_FIRST: Code = "0123"
OPENING_SECOND_BY_FEEDBACK: Dict[Feedback, Code] = {
    (0, 0): "4567",
    (0, 1): "1045",
    (0, 2): "1435",
    (0, 3): "1435",
    (0, 4): "1230",
    (1, 0): "0456",
    (1, 1): "0145",
    (1, 2): "0245",
    (1, 3): "0134",
    (2, 0): "0245",
    (2, 1): "0245",
    (2, 2): "0214",
    (3, 0): "0245",
    (4, 0): "0123",
}

CACHE_DIR = Path(".questline_cache")
MATRIX_CACHE_NAME = "feedback_matrix_v1.bin"
MATRIX_MAGIC = b"QUESTLINE_FEEDBACK_MATRIX_V1\n"
MATRIX_SIZE = len(ALL_CODES) * len(ALL_CODES)

ONLINE_SAFE_MODE = True
MAX_MECH_REPORT_CANDIDATES = 650


def raw_feedback(answer: Code, guess: Code) -> Feedback:
    bulls = sum(a == g for a, g in zip(answer, guess))
    common = sum(ch in answer for ch in guess)
    return bulls, common - bulls


def fb_to_str(fb: Feedback) -> str:
    return f"{fb[0]}b{fb[1]}c"


def parse_feedback(value: Union[Feedback, str]) -> Feedback:
    if isinstance(value, tuple):
        return value
    text = str(value).strip().lower()
    patterns = [
        r"^\s*(\d)\s*b\s*(\d)\s*c\s*$",
        r"^\s*(\d)\s*a\s*(\d)\s*b\s*$",
        r"^\s*(\d)\s*,\s*(\d)\s*$",
    ]
    for pattern in patterns:
        match = re.match(pattern, text)
        if match:
            return int(match.group(1)), int(match.group(2))
    if len(text) == 2 and text[0].isdigit() and text[1].isdigit():
        return int(text[0]), int(text[1])
    raise ValueError(f"Cannot parse feedback: {value}")


def validate_feedback(feedback: Feedback) -> Feedback:
    bulls, cows = feedback
    if bulls < 0 or cows < 0 or bulls > CODE_LEN or cows > CODE_LEN - bulls:
        raise ValueError(f"Invalid feedback: {feedback}")
    return feedback


def validate_code(code: Code) -> Code:
    code = str(code).strip()
    if len(code) != CODE_LEN:
        raise ValueError("Code must have 4 digits.")
    if len(set(code)) != CODE_LEN:
        raise ValueError("Digits must not repeat.")
    if not all(ch in DIGITS for ch in code):
        raise ValueError("Code must contain digits 0-9 only.")
    return code


def normalize_history(history: History) -> List[Tuple[Code, Feedback]]:
    return [(validate_code(guess), validate_feedback(parse_feedback(fb))) for guess, fb in history]


class _QuestLineCore:
    """Narrative-driven Bulls & Cows solver.

    The first and second moves are served from a small opening book. The feedback
    matrix is loaded lazily only when the solver needs deeper reasoning.
    """

    def __init__(self, use_cache: bool = True, verbose: bool = False) -> None:
        self.use_cache = use_cache
        self.verbose = verbose
        self.feedback_matrix: Optional[List[bytearray]] = None
        self._best_cache: Dict[Tuple[Tuple[int, ...], str], Tuple[Tuple[float, int, int, str], int, float, int, int]] = {}
        self._stats_cache: Dict[Tuple[int, ...], Dict[str, object]] = {}
        self._weights_cache: Dict[Tuple[int, ...], Tuple[Dict[int, float], Tuple[int, ...]]] = {}

    # ------------------------------------------------------------------
    # Matrix cache
    # ------------------------------------------------------------------

    @property
    def cache_path(self) -> Path:
        return CACHE_DIR / MATRIX_CACHE_NAME

    def ensure_matrix(self) -> None:
        if self.feedback_matrix is not None:
            return
        if self.use_cache and self.cache_path.exists():
            self.feedback_matrix = self._load_matrix_cache()
            return
        self.feedback_matrix = self._build_feedback_matrix()
        if self.use_cache:
            self._save_matrix_cache(self.feedback_matrix)

    def _load_matrix_cache(self) -> List[bytearray]:
        if self.verbose:
            print(f"Loading feedback matrix cache: {self.cache_path}")
        data = self.cache_path.read_bytes()
        if not data.startswith(MATRIX_MAGIC):
            raise ValueError("Invalid QuestLine matrix cache header. Delete .questline_cache and rebuild.")
        payload = data[len(MATRIX_MAGIC):]
        if len(payload) != MATRIX_SIZE:
            raise ValueError("Invalid QuestLine matrix cache size. Delete .questline_cache and rebuild.")
        matrix = []
        offset = 0
        row_len = len(ALL_CODES)
        for _ in ALL_CODES:
            matrix.append(bytearray(payload[offset: offset + row_len]))
            offset += row_len
        if self.verbose:
            print("Feedback matrix cache loaded.")
        return matrix

    def _save_matrix_cache(self, matrix: List[bytearray]) -> None:
        CACHE_DIR.mkdir(exist_ok=True)
        if self.verbose:
            print(f"Saving feedback matrix cache: {self.cache_path}")
        payload = b"".join(bytes(row) for row in matrix)
        self.cache_path.write_bytes(MATRIX_MAGIC + payload)

    def _build_feedback_matrix(self) -> List[bytearray]:
        if self.verbose:
            print("Building feedback matrix. This happens once and may take a while...")
        start = time.time()
        matrix: List[bytearray] = []
        for guess in ALL_CODES:
            row = bytearray(len(ALL_CODES))
            for answer_index, answer in enumerate(ALL_CODES):
                row[answer_index] = FB_TO_BYTE[raw_feedback(answer, guess)]
            matrix.append(row)
        if self.verbose:
            print(f"Feedback matrix built in {time.time() - start:.2f}s.")
        return matrix

    def feedback(self, answer: Code, guess: Code) -> Feedback:
        # For one-off feedback, raw calculation is faster than forcing matrix load.
        return raw_feedback(validate_code(answer), validate_code(guess))

    def matrix_feedback(self, answer_index: int, guess_index: int) -> Feedback:
        self.ensure_matrix()
        assert self.feedback_matrix is not None
        return BYTE_TO_FB[self.feedback_matrix[guess_index][answer_index]]

    # ------------------------------------------------------------------
    # Candidate filtering and mechanical anchors
    # ------------------------------------------------------------------

    def filter_candidates(self, history: History) -> Tuple[int, ...]:
        normalized = normalize_history(history)
        if not normalized:
            return ALL_INDEXES
        self.ensure_matrix()
        assert self.feedback_matrix is not None
        candidates = list(ALL_INDEXES)
        for guess, fb in normalized:
            row = self.feedback_matrix[CODE_TO_INDEX[guess]]
            target = FB_TO_BYTE[fb]
            candidates = [idx for idx in candidates if row[idx] == target]
        return tuple(candidates)

    def bucket_counts(self, candidates: Tuple[int, ...], guess_index: int) -> Dict[int, int]:
        self.ensure_matrix()
        assert self.feedback_matrix is not None
        row = self.feedback_matrix[guess_index]
        counts: Dict[int, int] = defaultdict(int)
        for answer_index in candidates:
            counts[row[answer_index]] += 1
        return counts

    def avg_remaining(self, candidates: Tuple[int, ...], guess_index: int) -> Tuple[float, int, int]:
        counts = self.bucket_counts(candidates, guess_index)
        n = len(candidates)
        return sum(v * v for v in counts.values()) / n, max(counts.values()), len(counts)

    def best_pure_guess(self, candidates: Tuple[int, ...], mode: str = "avg") -> Tuple[int, float, int, int]:
        key = (candidates, mode)
        cached = self._best_cache.get(key)
        if cached is not None:
            _, guess_index, exp, max_bucket, bucket_count = cached
            return guess_index, exp, max_bucket, bucket_count
        candidate_set = set(candidates)
        best: Optional[Tuple[Tuple[float, int, int, str], int, float, int, int]] = None
        for guess_index, guess in enumerate(ALL_CODES):
            exp, max_bucket, bucket_count = self.avg_remaining(candidates, guess_index)
            candidate_penalty = 0 if guess_index in candidate_set else 1
            sort_key = (exp, max_bucket, candidate_penalty, guess) if mode == "avg" else (max_bucket, exp, candidate_penalty, guess)
            if best is None or sort_key < best[0]:
                best = (sort_key, guess_index, exp, max_bucket, bucket_count)
        assert best is not None
        self._best_cache[key] = best
        _, guess_index, exp, max_bucket, bucket_count = best
        return guess_index, exp, max_bucket, bucket_count

    # ------------------------------------------------------------------
    # Stats and weighted candidate model
    # ------------------------------------------------------------------

    def stats(self, candidates: Tuple[int, ...]) -> Dict[str, object]:
        cached = self._stats_cache.get(candidates)
        if cached is not None:
            return cached
        n = len(candidates)
        dc: Counter[str] = Counter()
        pc: List[Counter[str]] = [Counter() for _ in range(CODE_LEN)]
        pair: Counter[str] = Counter()
        tri: Counter[str] = Counter()
        quad: Counter[str] = Counter()
        group_strength = {name: 0.0 for name in FIXED_GROUPS}
        for index in candidates:
            code = ALL_CODES[index]
            dc.update(code)
            for pos, ch in enumerate(code):
                pc[pos][ch] += 1
            sorted_code = sorted(code)
            for combo in combinations(sorted_code, 2):
                pair["".join(combo)] += 1
            for combo in combinations(sorted_code, 3):
                tri["".join(combo)] += 1
            quad["".join(sorted_code)] += 1
            for name, group in FIXED_GROUPS.items():
                group_strength[name] += sum(ch in group for ch in code)
        for name in group_strength:
            group_strength[name] /= n
        freqs = {digit: dc[digit] / n for digit in DIGITS}
        quad_common = quad.most_common()
        result = {
            "n": n,
            "dc": dc,
            "pc": pc,
            "pair": pair,
            "tri": tri,
            "quad": quad,
            "group_strength": group_strength,
            "freqs": freqs,
            "weak_threshold": sorted(freqs.values())[2],
            "top_digits": [d for d, _ in dc.most_common(4)],
            "top_pairs": [p for p, _ in pair.most_common(6)],
            "top_triples": [t for t, _ in tri.most_common(6)],
            "top_quad_count": quad_common[0][1] if quad_common else 0,
            "second_quad_count": quad_common[1][1] if len(quad_common) > 1 else 0,
        }
        self._stats_cache[candidates] = result
        return result

    @staticmethod
    def fixed_signature(code: Code) -> Tuple[int, ...]:
        return tuple(sum(ch in group for ch in code) for group in FIXED_GROUPS.values())

    def candidate_weights(self, candidates: Tuple[int, ...], stats: Dict[str, object]) -> Tuple[Dict[int, float], Tuple[int, ...]]:
        cached = self._weights_cache.get(candidates)
        if cached is not None:
            return cached
        worlds: DefaultDict[Tuple[int, ...], List[int]] = defaultdict(list)
        for index in candidates:
            worlds[self.fixed_signature(ALL_CODES[index])].append(index)
        total = len(candidates)
        world_scores = {signature: (len(members) / total) ** 1.35 for signature, members in worlds.items()}
        weights: Dict[int, float] = {}
        for signature, members in worlds.items():
            for index in members:
                weights[index] = world_scores[signature] * self._candidate_base_weight(ALL_CODES[index], stats)
        weight_sum = sum(weights.values())
        if weight_sum > 0:
            weights = {k: v / weight_sum for k, v in weights.items()}
        main_signature = max(world_scores, key=world_scores.get)
        result = (weights, tuple(worlds[main_signature]))
        self._weights_cache[candidates] = result
        return result

    def world_line_analysis(self, history: History) -> Dict[str, object]:
        """Summarize the strongest fixed-group world and its supporting patterns."""
        normalized = normalize_history(history)
        candidates = self.filter_candidates(normalized)
        if not candidates:
            return {"candidate_count": 0, "main_world": None, "worlds": [], "top_pairs": [], "top_triples": [], "top_quads": [], "timeline": []}

        stats = self.stats(candidates)
        world_counts: Counter[Tuple[int, ...]] = Counter(self.fixed_signature(ALL_CODES[index]) for index in candidates)
        ranked_worlds = sorted(world_counts.items(), key=lambda item: (-item[1], item[0]))
        main_signature, main_count = ranked_worlds[0]
        total = len(candidates)
        tied_worlds = [signature for signature, count in ranked_worlds if count == main_count]

        def ranked(counter: Counter[str], limit: int) -> List[Dict[str, object]]:
            return [{"pattern": key, "count": count, "support": count / total} for key, count in counter.most_common(limit)]

        worlds = [
            {
                "signature": list(signature),
                "groups": [name for name, amount in zip(FIXED_GROUPS, signature) if amount],
                "count": count,
                "support": count / total,
                "is_main": signature == main_signature,
            }
            for signature, count in sorted(world_counts.items(), key=lambda item: (-item[1], item[0]))
        ]
        timeline: List[Dict[str, object]] = []
        for round_number in range(len(normalized) + 1):
            prefix = normalized[:round_number]
            prefix_candidates = self.filter_candidates(prefix)
            if not prefix_candidates:
                timeline.append({"round": round_number, "candidate_count": 0, "main_world": None, "support": 0.0})
                continue
            prefix_worlds = Counter(self.fixed_signature(ALL_CODES[index]) for index in prefix_candidates)
            signature, count = sorted(prefix_worlds.items(), key=lambda item: (-item[1], item[0]))[0]
            prefix_tied_count = sum(1 for world_count in prefix_worlds.values() if world_count == count)
            timeline.append({
                "round": round_number,
                "candidate_count": len(prefix_candidates),
                "main_world": list(signature),
                "support": count / len(prefix_candidates),
                "tied_world_count": prefix_tied_count,
            })

        previous_support = None
        for item in timeline:
            support = item["support"]
            item["support_delta"] = None if previous_support is None else support - previous_support
            previous_support = support

        runner_up_count = ranked_worlds[1][1] if len(ranked_worlds) > 1 else 0
        lead = (main_count - runner_up_count) / total
        confidence = "tied" if len(tied_worlds) > 1 else ("weak" if lead < 0.05 else "clear")
        main_world = {
            "signature": list(main_signature),
            "groups": [name for name, amount in zip(FIXED_GROUPS, main_signature) if amount],
            "count": main_count,
            "support": main_count / total,
            "lead_over_runner_up": lead,
            "runner_up_support": runner_up_count / total,
            "confidence": confidence,
            "tied_world_count": len(tied_worlds),
        }

        return {
            "candidate_count": total,
            "main_world": main_world,
            "worlds": worlds,
            "top_pairs": ranked(stats["pair"], 5),
            "top_triples": ranked(stats["tri"], 5),
            "top_quads": ranked(stats["quad"], 5),
            "timeline": timeline,
        }

    @staticmethod
    def _changed_digit_facts(before: Dict[str, object], after: Dict[str, object]) -> Dict[str, List[str]]:
        changes = {"confirmed": [], "likely": [], "excluded": [], "weakened": [], "strengthened": []}
        before_status = before.get("digit_status", {})
        after_status = after.get("digit_status", {})
        rank = {"excluded": 0, "possible": 1, "likely": 2, "confirmed": 3}
        for digit in DIGITS:
            old = before_status.get(digit, {}).get("status", "possible")
            new = after_status.get(digit, {}).get("status", "possible")
            if old == new:
                continue
            if new == "confirmed":
                changes["confirmed"].append(digit)
            elif new == "likely":
                changes["likely"].append(digit)
            elif new == "excluded":
                changes["excluded"].append(digit)
            if rank.get(new, 1) > rank.get(old, 1):
                changes["strengthened"].append(digit)
            else:
                changes["weakened"].append(digit)
        return changes

    @staticmethod
    def _changed_position_facts(before: Dict[str, object], after: Dict[str, object]) -> Dict[str, List[Dict[str, object]]]:
        changes = {"strengthened": [], "weakened": [], "confirmed": [], "excluded": []}
        before_support = before.get("digit_position_support", {})
        after_support = after.get("digit_position_support", {})
        before_status = before.get("digit_status", {})
        after_status = after.get("digit_status", {})
        for digit in DIGITS:
            old_values = before_support.get(digit, [0.0] * CODE_LEN)
            new_values = after_support.get(digit, [0.0] * CODE_LEN)
            for position, (old, new) in enumerate(zip(old_values, new_values)):
                delta = new - old
                old_status = before_status.get(digit, {}).get("position_status", ["possible"] * CODE_LEN)[position]
                new_status = after_status.get(digit, {}).get("position_status", ["possible"] * CODE_LEN)[position]
                item = {
                    "digit": digit,
                    "position": position,
                    "old_support": old,
                    "new_support": new,
                    "support_delta": delta,
                }
                if new_status == "confirmed" and old_status != "confirmed":
                    changes["confirmed"].append(item)
                elif new_status == "excluded" and old_status != "excluded":
                    changes["excluded"].append(item)
                elif delta >= 0.10:
                    changes["strengthened"].append(item)
                elif delta <= -0.10:
                    changes["weakened"].append(item)
        return changes

    def explain_transition(self, history: History, guess: Code, feedback: Union[Feedback, str]) -> Dict[str, object]:
        """Explain one action as a transition from one investigation state to another."""
        normalized = normalize_history(history)
        guess = validate_code(guess)
        feedback = validate_feedback(parse_feedback(feedback))
        before = self.investigation_state(normalized)
        action = self.classify_action(guess, normalized, before, CODE_TO_INDEX[guess] in set(self.filter_candidates(normalized)))
        rationale = self.action_rationale(action, before)
        after_history = normalized + [(guess, feedback)]
        after = self.investigation_state(after_history)
        before_world = self.world_line_analysis(normalized)
        after_world = self.world_line_analysis(after_history)
        digit_changes = self._changed_digit_facts(before, after)
        position_changes = self._changed_position_facts(before, after)
        group_changes = []
        for group in GROUP_ORDER:
            old = before.get("group_states", {}).get(group, {}).get("status")
            new = after.get("group_states", {}).get(group, {}).get("status")
            if old != new:
                group_changes.append({"group": group, "before": old, "after": new})
        old_task = before.get("task")
        new_task = after.get("task")
        old_main = (before_world.get("main_world") or {}).get("groups", [])
        new_main = (after_world.get("main_world") or {}).get("groups", [])
        if feedback == (CODE_LEN, 0):
            event_type = "solution_revealed"
            title = "答案被直接确认"
        elif after.get("candidate_count", 0) == 0:
            event_type = "state_inconsistent"
            title = "这条反馈与现有证据冲突"
        elif digit_changes["confirmed"] or digit_changes["excluded"]:
            event_type = "identity_breakthrough"
            title = "数字身份发生突破"
        elif any(position_changes.values()):
            event_type = "position_breakthrough"
            title = "数字位置发生变化"
        elif old_task != new_task:
            event_type = "investigation_shifted"
            title = "调查任务发生转移"
        elif old_main != new_main:
            event_type = "worldline_shifted"
            title = "主世界线发生变化"
        elif after.get("candidate_count", 0) < before.get("candidate_count", 0) * 0.25:
            event_type = "candidate_space_collapsed"
            title = "可能性空间明显收束"
        else:
            event_type = "evidence_updated"
            title = "证据继续累积"
        return {
            "round": len(after_history),
            "type": event_type,
            "title": title,
            "action": {"guess": guess, "feedback": fb_to_str(feedback), "classification": action},
            "decision": {"task": old_task, "rationale": rationale},
            "before": {"candidate_count": before.get("candidate_count"), "task": old_task, "main_world": old_main},
            "after": {"candidate_count": after.get("candidate_count"), "task": new_task, "main_world": new_main},
            "facts": digit_changes,
            "position_facts": position_changes,
            "group_changes": group_changes,
            "worldline": {
                "before_support": (before_world.get("main_world") or {}).get("support", 0.0),
                "after_support": (after_world.get("main_world") or {}).get("support", 0.0),
                "before_confidence": (before_world.get("main_world") or {}).get("confidence"),
                "after_confidence": (after_world.get("main_world") or {}).get("confidence"),
            },
            "narrative": self._transition_narrative(
                title, guess, action, feedback, before, after, digit_changes, position_changes, old_task, new_task, rationale
            ),
        }

    @staticmethod
    def action_rationale(action: Dict[str, object], state: Dict[str, object]) -> str:
        """Explain why an action answers the current investigation task."""
        task = state.get("task")
        groups = ", ".join(action.get("new_groups", [])) or "已调查组"
        if task == "establish_foundation":
            return "先建立基础数字关系，给后续组间比较提供共同参照。"
        if task == "introduce_45":
            return "01 与 23 已有第一层证据，现在引入 45，观察好人主干是否延伸。"
        if task in {"investigate_outer_groups", "cross_test_new_group"}:
            return f"当前重点是引入未调查信息，行动选择测试 {groups}，同时保持基本 AVG/MM 效率。"
        if task == "converge_outer_choice":
            return "外围仍有对称解释，选择一个外围分支施加压力，而不是假定某个数字已经领先。"
        if task == "resolve_group_conflict":
            conflicts = ", ".join(state.get("strong_conflict_groups", [])) or "组内关系"
            return f"当前需要拆解 {conflicts} 的组内关系，优先获取身份或位置上的分裂证据。"
        if task == "apply_position_pressure":
            digits = "".join(state.get("position_uncertainty", [])) or "已知数字"
            return f"身份线索已经足够，下一步针对 {digits} 的位置关系施加压力。"
        if task == "resolve_endgame":
            return "剩余世界很少，优先直接验证候选答案，避免继续制造无意义的外围猜测。"
        return f"行动类型为 {action.get('type', 'unknown')}，用于推进当前调查。"

    @staticmethod
    def _transition_narrative(title: str, guess: Code, action: Dict[str, object], feedback: Feedback, before: Dict[str, object], after: Dict[str, object], changes: Dict[str, List[str]], position_changes: Dict[str, List[Dict[str, object]]], old_task: str, new_task: str, rationale: str) -> str:
        parts = [f"{title}：因为{rationale}行动 {guess}，得到 {fb_to_str(feedback)}。"]
        if changes["confirmed"]:
            parts.append(f"数字 {''.join(changes['confirmed'])} 在剩余世界中已基本确认。")
        if changes["excluded"]:
            parts.append(f"数字 {''.join(changes['excluded'])} 被当前证据排除。")
        if changes["weakened"]:
            parts.append(f"数字 {''.join(changes['weakened'])} 的支持度下降。")
        strengthened_positions = position_changes["strengthened"] + position_changes["confirmed"]
        weakened_positions = position_changes["weakened"] + position_changes["excluded"]
        if strengthened_positions:
            details = "、".join(f"{item['digit']}→第{item['position'] + 1}位" for item in strengthened_positions[:3])
            parts.append(f"位置证据增强：{details}。")
        if weakened_positions:
            details = "、".join(f"{item['digit']}×第{item['position'] + 1}位" for item in weakened_positions[:3])
            parts.append(f"位置解释被削弱：{details}。")
        if after.get("candidate_count") != before.get("candidate_count"):
            parts.append(f"结果空间从 {before.get('candidate_count')} 缩小到 {after.get('candidate_count')}。")
        if old_task != new_task:
            parts.append(f"调查从 {old_task} 转向 {new_task}。")
        return "".join(parts)

    def _candidate_base_weight(self, code: Code, stats: Dict[str, object]) -> float:
        n = stats["n"]
        dc: Counter[str] = stats["dc"]
        pc: List[Counter[str]] = stats["pc"]
        pair: Counter[str] = stats["pair"]
        tri: Counter[str] = stats["tri"]
        quad: Counter[str] = stats["quad"]
        sorted_code = sorted(code)
        digit_score = 1.0
        for ch in code:
            digit_score *= 0.35 + dc[ch] / n
        position_score = 1.0
        for pos, ch in enumerate(code):
            position_score *= 0.35 + pc[pos][ch] / n
        pair_score = 1.0
        for combo in combinations(sorted_code, 2):
            pair_score *= 0.55 + 0.35 * (pair["".join(combo)] / n)
        triple_score = 1.0
        for combo in combinations(sorted_code, 3):
            triple_score *= 0.70 + 0.18 * (tri["".join(combo)] / n)
        quad_score = 0.80 + 0.12 * (quad["".join(sorted_code)] / n)
        penalty = 1.0
        for digit in stats["top_digits"]:
            if digit not in code:
                penalty *= 0.86
        for p in stats["top_pairs"]:
            if not all(ch in code for ch in p):
                penalty *= 0.94
        for t in stats["top_triples"]:
            if not all(ch in code for ch in t):
                penalty *= 0.97
        penalty *= 0.80 + 0.40 * (quad["".join(sorted_code)] / n)
        return digit_score * position_score * pair_score * triple_score * quad_score * penalty


class _QuestLineReasoningLayer(_QuestLineCore):
    """Organize transition explanations into a continuous investigation story."""

    CHAPTERS: Dict[str, Tuple[str, str]] = {
        "establish_foundation": ("prologue", "案件建立"),
        "introduce_45": ("foundation", "核心事实"),
        "investigate_outer_groups": ("new_witnesses", "新的证人"),
        "cross_test_new_group": ("outer_split", "外围分裂"),
        "converge_outer_choice": ("outer_split", "外围分裂"),
        "resolve_group_conflict": ("group_conflict", "阵营冲突"),
        "apply_position_pressure": ("position_evidence", "位置证据"),
        "resolve_endgame": ("convergence", "收束"),
    }

    def __init__(self, solver: Optional[QuestLineSolver] = None) -> None:
        self.solver = solver or QuestLineSolver()
        self.events: List[Dict[str, object]] = []
        self.chapters: List[Dict[str, object]] = []
        self.digit_index: DefaultDict[str, List[int]] = defaultdict(list)
        self.group_index: DefaultDict[str, List[int]] = defaultdict(list)

    @classmethod
    def from_history(cls, history: History, solver: Optional[QuestLineSolver] = None) -> "StoryBook":
        book = cls(solver)
        normalized = normalize_history(history)
        prefix: List[Tuple[Code, Feedback]] = []
        for guess, feedback in normalized:
            book.add_turn(prefix, guess, feedback)
            prefix.append((guess, feedback))
        return book

    def add_turn(self, history: History, guess: Code, feedback: Union[Feedback, str]) -> Dict[str, object]:
        event = dict(self.solver.explain_transition(history, guess, feedback))
        chapter_key, chapter_title = self._chapter_for(event)
        event["chapter"] = {"key": chapter_key, "title": chapter_title}
        event_index = len(self.events)
        self.events.append(event)
        self._index_event(event_index, event)
        if not self.chapters or self.chapters[-1]["key"] != chapter_key:
            self.chapters.append({
                "key": chapter_key,
                "title": chapter_title,
                "start_round": event["round"],
                "end_round": event["round"],
                "event_indexes": [event_index],
                "narratives": [event["narrative"]],
            })
        else:
            chapter = self.chapters[-1]
            chapter["end_round"] = event["round"]
            chapter["event_indexes"].append(event_index)
            chapter["narratives"].append(event["narrative"])
        return event

    def _chapter_for(self, event: Dict[str, object]) -> Tuple[str, str]:
        if event["type"] == "solution_revealed":
            return "resolution", "终章：破案"
        task = event["after"].get("task")
        if task in self.CHAPTERS:
            key, title = self.CHAPTERS[task]
            return key, title
        return "investigation", "调查展开"

    def _index_event(self, event_index: int, event: Dict[str, object]) -> None:
        facts = event.get("facts", {})
        for category in ("confirmed", "likely", "excluded", "weakened", "strengthened"):
            for digit in facts.get(category, []):
                if event_index not in self.digit_index[digit]:
                    self.digit_index[digit].append(event_index)
        for category in ("strengthened", "weakened", "confirmed", "excluded"):
            for item in event.get("position_facts", {}).get(category, []):
                digit = item.get("digit")
                if digit and event_index not in self.digit_index[digit]:
                    self.digit_index[digit].append(event_index)
        for change in event.get("group_changes", []):
            group = change.get("group")
            if group and event_index not in self.group_index[group]:
                self.group_index[group].append(event_index)

    def chapter(self, key: str) -> Optional[Dict[str, object]]:
        return next((item for item in self.chapters if item["key"] == key), None)

    def to_dict(self) -> Dict[str, object]:
        return {
            "event_count": len(self.events),
            "chapter_count": len(self.chapters),
            "chapters": self.chapters,
            "events": self.events,
            "digit_index": dict(self.digit_index),
            "group_index": dict(self.group_index),
        }

    def weighted_stats(self, candidates: Tuple[int, ...], guess_index: int, weights: Dict[int, float]) -> Tuple[float, float, int]:
        self.ensure_matrix()
        assert self.feedback_matrix is not None
        row = self.feedback_matrix[guess_index]
        buckets: DefaultDict[int, List[int]] = defaultdict(list)
        for answer_index in candidates:
            buckets[row[answer_index]].append(answer_index)
        total_w = sum(weights[idx] for idx in candidates)
        expected = 0.0
        max_weight = 0.0
        for bucket in buckets.values():
            bucket_w = sum(weights[idx] for idx in bucket)
            expected += (bucket_w / total_w) * len(bucket)
            max_weight = max(max_weight, bucket_w)
        return expected, max_weight, len(buckets)

    # ------------------------------------------------------------------
    # Signal modes and strategy scoring
    # ------------------------------------------------------------------

    def classify_action(self, guess: Code, history: History, investigation: Dict[str, object], is_candidate: bool) -> Dict[str, object]:
        """Describe what a guess is investigating, independent of its score."""
        normalized = normalize_history(history)
        if any(previous_guess == guess for previous_guess, _ in normalized):
            return {
                "type": "redundant",
                "reason": "repeats an already tested guess without adding information",
                "groups": [group for group in GROUP_ORDER if any(digit in FIXED_GROUPS[group] for digit in guess)],
                "new_groups": [],
                "new_group_digit_counts": {},
                "new_positions": [],
            }
        tested_groups = set(investigation.get("tested_groups", []))
        guess_groups = [group for group in GROUP_ORDER if any(digit in FIXED_GROUPS[group] for digit in guess)]
        new_groups = [group for group in guess_groups if group not in tested_groups]
        new_group_digit_counts = {
            group: sum(digit in FIXED_GROUPS[group] for digit in guess)
            for group in new_groups
        }
        used = self.used_positions(normalized)
        new_positions = [position for position, digit in enumerate(guess) if position not in used.get(digit, set())]

        if is_candidate and investigation.get("task") == "resolve_endgame":
            action_type = "candidate_probe"
            reason = "tests a remaining candidate directly"
        elif new_groups:
            action_type = "group_probe"
            reason = "introduces untested groups"
        elif new_positions:
            action_type = "position_probe"
            reason = "reuses tested digits in new positions"
        elif is_candidate:
            action_type = "candidate_probe"
            reason = "tests a remaining candidate"
        else:
            action_type = "mechanical_split"
            reason = "primarily separates feedback buckets"

        return {
            "type": action_type,
            "reason": reason,
            "groups": guess_groups,
            "new_groups": new_groups,
            "new_group_digit_counts": new_group_digit_counts,
            "new_positions": new_positions,
        }

    @staticmethod
    def action_is_eligible(action: Dict[str, object], task: str) -> bool:
        """Apply structural investigation rules before numerical ranking."""
        action_type = action.get("type")
        if action_type == "redundant":
            return False
        if task == "cross_test_new_group":
            if action_type != "group_probe":
                return False
            new_groups = action.get("new_groups", [])
            counts = action.get("new_group_digit_counts", {})
            if len(new_groups) != 1:
                return False
            new_group = new_groups[0]
            return counts.get(new_group) == 2
        if task == "converge_outer_choice":
            if action_type != "group_probe":
                return False
            new_groups = action.get("new_groups", [])
            counts = action.get("new_group_digit_counts", {})
            if len(new_groups) != 1:
                return False
            return counts.get(new_groups[0], 0) in {1, 2}
        return True


class StoryBook(_QuestLineReasoningLayer):
    """Public story organizer built on the solver's explanation layer."""

    def render(self, include_indexes: bool = False) -> str:
        """Render the investigation as a readable Chinese case book."""
        if not self.events:
            return "《QuestLine 案件记录》\n\n案件尚未开始。"

        lines = ["《QuestLine 案件记录》", "", f"共 {len(self.events)} 轮，形成 {len(self.chapters)} 个章节。"]
        for chapter in self.chapters:
            lines.extend(["", f"## {chapter['title']}"])
            for event_index in chapter["event_indexes"]:
                lines.append(self.events[event_index]["narrative"])

        final = self.events[-1]
        if final["type"] == "solution_revealed":
            lines.extend(["", "案件结论：反馈已经确认答案，调查结束。"])
        elif final["after"].get("candidate_count") == 0:
            lines.extend(["", "案件状态：反馈与现有证据冲突，需要检查输入或重新审理。"])
        else:
            lines.extend(["", f"案件状态：仍有 {final['after'].get('candidate_count')} 个可能世界，调查尚未结束。"])

        if include_indexes:
            lines.extend(["", "## 角色索引", self.render_digit_index()])
            lines.extend(["", "## 阵营索引", self.render_group_index()])
        return "\n".join(lines)

    def render_digit_index(self) -> str:
        """Render the rounds in which each digit's evidence changed."""
        rows = []
        for digit in DIGITS:
            rounds = self.digit_index.get(digit, [])
            if rounds:
                rows.append(f"数字 {digit}：第 {', '.join(str(index + 1) for index in rounds)} 轮出现关键变化")
        return "\n".join(rows) if rows else "暂时没有数字获得新的证据。"

    def render_group_index(self) -> str:
        """Render the groups whose internal relation changed."""
        rows = []
        for group in GROUP_ORDER:
            rounds = self.group_index.get(group, [])
            if rounds:
                rows.append(f"小组 {group}：第 {', '.join(str(index + 1) for index in rounds)} 轮关系发生变化")
        return "\n".join(rows) if rows else "暂时没有小组关系发生结构性变化。"


class QuestLineSolver(_QuestLineReasoningLayer):
    """Complete solver assembled from the core and investigation layers."""

    def __init__(self, use_cache: bool = True, verbose: bool = False) -> None:
        _QuestLineCore.__init__(self, use_cache=use_cache, verbose=verbose)

    def investigation_state(self, history: History) -> Dict[str, object]:
        """Build the factual investigation state without applying score weights.

        This is the first layer of the refactored engine. It describes what has
        been tested and what the remaining candidate set says about each group;
        it does not decide which candidate is more narratively likely.
        """
        normalized = normalize_history(history)
        candidates = self.filter_candidates(normalized)
        candidate_count = len(candidates)
        tested_groups = [
            group for group in GROUP_ORDER
            if any(any(digit in FIXED_GROUPS[group] for digit in guess) for guess, _ in normalized)
        ]
        untested_groups = [group for group in GROUP_ORDER if group not in tested_groups]

        group_states: Dict[str, Dict[str, object]] = {}
        for group in GROUP_ORDER:
            occupancy = Counter(
                sum(digit in FIXED_GROUPS[group] for digit in ALL_CODES[index])
                for index in candidates
            )
            zero_count = occupancy.get(0, 0)
            two_count = occupancy.get(2, 0)
            if not normalized:
                status = "unobserved"
            elif candidate_count == 0:
                status = "inconsistent"
            elif zero_count == candidate_count:
                status = "excluded"
            elif two_count == candidate_count:
                status = "full"
            elif group not in tested_groups:
                status = "unobserved"
            elif zero_count == 0:
                status = "present"
            else:
                status = "contested"
            group_states[group] = {
                "status": status,
                "tested": group in tested_groups,
                "occupancy_counts": {str(amount): occupancy.get(amount, 0) for amount in range(3)},
                "possible_candidate_support": (candidate_count - zero_count) / candidate_count if candidate_count else 0.0,
                "full_candidate_support": two_count / candidate_count if candidate_count else 0.0,
            }

        digit_support = {
            digit: sum(digit in ALL_CODES[index] for index in candidates) / candidate_count
            if candidate_count else 0.0
            for digit in DIGITS
        }
        digit_position_support = {
            digit: [
                sum(ALL_CODES[index][position] == digit for index in candidates) / candidate_count
                if candidate_count else 0.0
                for position in range(CODE_LEN)
            ]
            for digit in DIGITS
        }

        def support_status(support: float) -> str:
            if support <= 0.02:
                return "excluded"
            if support >= 0.98:
                return "confirmed"
            if support >= 0.75:
                return "likely"
            return "possible"

        digit_status = {}
        for digit, support in digit_support.items():
            positions = digit_position_support[digit]
            digit_status[digit] = {
                "support": support,
                "status": support_status(support),
                "position_support": positions,
                "position_status": [support_status(value) for value in positions],
                "most_likely_position": max(range(CODE_LEN), key=lambda position: positions[position]),
            }

        group_relations: Dict[str, Dict[str, object]] = {}
        for group in GROUP_ORDER:
            group_digits = sorted(FIXED_GROUPS[group])
            first, second = group_digits
            first_support = digit_support[first]
            second_support = digit_support[second]
            support_gap = abs(first_support - second_support)
            position_gap = max(
                abs(left - right)
                for left, right in zip(
                    digit_position_support[first], digit_position_support[second]
                )
            )
            both_supported = first_support > 0.25 and second_support > 0.25
            both_excluded = first_support <= 0.02 and second_support <= 0.02
            one_strong_one_weak = (
                max(first_support, second_support) >= 0.75
                and min(first_support, second_support) <= 0.25
            )
            if both_excluded:
                relation = "both_excluded"
            elif one_strong_one_weak:
                relation = "one_strong_one_weak"
            elif both_supported and support_gap <= 0.03:
                relation = "symmetric"
            elif both_supported and position_gap >= 0.35:
                relation = "position_conflict"
            elif both_supported:
                relation = "both_supported"
            else:
                relation = "unresolved"
            group_relations[group] = {
                "digits": group_digits,
                "relation": relation,
                "support": {first: first_support, second: second_support},
                "support_gap": support_gap,
                "position_gap": position_gap,
                "both_supported": both_supported,
                "both_excluded": both_excluded,
            }
        confirmed_digits = [digit for digit in DIGITS if digit_status[digit]["status"] == "confirmed"]
        likely_digits = [digit for digit in DIGITS if digit_status[digit]["status"] == "likely"]
        excluded_digits = [digit for digit in DIGITS if digit_status[digit]["status"] == "excluded"]
        weak_tested_groups = [
            group for group in tested_groups
            if group_states[group]["possible_candidate_support"] <= 0.15
        ]
        outer_supports = [digit_support[digit] for digit in "6789"]
        outer_is_symmetric = bool(outer_supports) and max(outer_supports) - min(outer_supports) <= 0.03
        strong_conflict_groups = [
            group for group, relation in group_relations.items()
            if relation["relation"] in {"one_strong_one_weak", "position_conflict"}
        ]
        position_uncertainty = [
            digit for digit in DIGITS
            if digit_status[digit]["status"] in {"confirmed", "likely"}
            and max(digit_position_support[digit]) < 0.98
        ]

        if not normalized:
            task = "establish_foundation"
        elif set(tested_groups) == {"01", "23"} and "45" not in tested_groups:
            task = "introduce_45"
        elif candidate_count <= 12:
            task = "resolve_endgame"
        elif strong_conflict_groups and not untested_groups:
            task = "resolve_group_conflict"
        elif position_uncertainty and not untested_groups:
            task = "apply_position_pressure"
        elif candidate_count <= 150 and (len(confirmed_digits) >= 3 or (weak_tested_groups and outer_is_symmetric)):
            task = "converge_outer_choice"
        elif len(untested_groups) >= 1:
            task = "cross_test_new_group" if len(tested_groups) >= 2 else "investigate_outer_groups"
        elif any(state["status"] == "contested" for state in group_states.values()):
            task = "resolve_group_conflict"
        else:
            task = "apply_position_pressure"

        available_actions = ["group_probe", "position_probe", "candidate_probe", "mechanical_split"]
        if task in {"establish_foundation", "introduce_45", "cross_test_new_group", "investigate_outer_groups", "converge_outer_choice"}:
            preferred_actions = ["group_probe", "position_probe"]
        elif task == "resolve_endgame":
            preferred_actions = ["candidate_probe", "mechanical_split"]
        elif task == "resolve_group_conflict":
            preferred_actions = ["group_probe", "position_probe", "mechanical_split"]
        else:
            preferred_actions = ["position_probe", "group_probe", "mechanical_split"]

        return {
            "round": len(normalized),
            "candidate_count": candidate_count,
            "tested_groups": tested_groups,
            "untested_groups": untested_groups,
            "group_states": group_states,
            "digit_support": digit_support,
            "digit_position_support": digit_position_support,
            "digit_status": digit_status,
            "confirmed_digits": confirmed_digits,
            "likely_digits": likely_digits,
            "excluded_digits": excluded_digits,
            "weak_tested_groups": weak_tested_groups,
            "group_relations": group_relations,
            "strong_conflict_groups": strong_conflict_groups,
            "position_uncertainty": position_uncertainty,
            "outer_is_symmetric": outer_is_symmetric,
            "task": task,
            "available_actions": available_actions,
            "preferred_actions": preferred_actions,
            "task_status": "ready",
            "task_policy": self.task_policy(task, candidate_count),
        }

    def game_phase(self, history: List[Tuple[Code, Feedback]], candidates: Tuple[int, ...]) -> str:
        if not history:
            return "opening_first"
        if len(history) == 1 and history[0][0] == OPENING_FIRST:
            return "opening_second"
        if len(candidates) <= 12:
            return "endgame"
        return "case"

    @staticmethod
    def task_policy(task: str, candidate_count: int) -> Dict[str, object]:
        """Describe the current task's objective and efficiency contract."""
        policies = {
            "establish_foundation": ("weighted_expected", 1.20, 2.0, 1.35, 4),
            "introduce_45": ("weighted_expected", 1.20, 2.0, 1.35, 4),
            "investigate_outer_groups": ("weighted_expected", 1.35, 2.5, 1.50, 5),
            "cross_test_new_group": ("weighted_expected", 1.35, 2.5, 1.50, 5),
            "converge_outer_choice": ("main_world_expected", 1.55, 3.0, 1.75, 6),
            "resolve_group_conflict": ("main_world_expected", 1.45, 3.0, 1.65, 6),
            "apply_position_pressure": ("normal_expected", 1.30, 2.5, 1.50, 5),
            "resolve_endgame": ("normal_max_bucket", 1.80, 3.0, 2.00, 6),
        }
        objective, exp_ratio, exp_slack, max_ratio, max_slack = policies.get(
            task, ("normal_expected", 1.35, 2.5, 1.55, 5)
        )
        return {
            "task": task,
            "objective": objective,
            "expected_ratio": exp_ratio,
            "expected_slack": exp_slack,
            "max_ratio": max_ratio,
            "max_slack": max_slack,
            "candidate_count": candidate_count,
        }

    @staticmethod
    def task_transition(task: str) -> Optional[str]:
        transitions = {
            "establish_foundation": "investigate_outer_groups",
            "introduce_45": "investigate_outer_groups",
            "investigate_outer_groups": "apply_position_pressure",
            "cross_test_new_group": "apply_position_pressure",
            "converge_outer_choice": "resolve_group_conflict",
            "resolve_group_conflict": "apply_position_pressure",
            "apply_position_pressure": "resolve_endgame",
            "resolve_endgame": None,
        }
        return transitions.get(task)

    @staticmethod
    def task_sort_key(item: Dict[str, object], investigation: Dict[str, object]) -> Tuple[object, ...]:
        """Rank eligible actions by the current investigation objective.

        The legacy score is deliberately absent from this key. AVG/MM limits
        are applied before sorting; the task objectives and deterministic code
        order decide the result from this point onward.
        """
        task = investigation.get("task")
        action = item["action"]
        action_type = action["type"]
        preferred = investigation.get("preferred_actions", [])
        action_rank = preferred.index(action_type) if action_type in preferred else len(preferred)

        if task in {"establish_foundation", "introduce_45", "cross_test_new_group", "investigate_outer_groups"}:
            objective = (
                item["weighted_expected"],
                item["main_world_expected"],
                item["normal_expected"],
                item["normal_max_bucket"],
            )
        elif task == "converge_outer_choice":
            objective = (
                item["main_world_expected"],
                item["weighted_expected"],
                item["normal_expected"],
                item["normal_max_bucket"],
            )
        elif task == "resolve_group_conflict":
            objective = (
                item["main_world_expected"],
                item["normal_max_bucket"],
                item["normal_expected"],
                item["weighted_expected"],
            )
        elif task == "apply_position_pressure":
            objective = (
                item["normal_expected"],
                item["normal_max_bucket"],
                item["weighted_expected"],
                item["main_world_expected"],
            )
        else:
            objective = (
                -int(item["is_candidate"]),
                item["normal_max_bucket"],
                item["normal_expected"],
                item["weighted_expected"],
                item["main_world_expected"],
            )
        return (action_rank,) + objective + (item["guess"],)

    @staticmethod
    def used_positions(history: List[Tuple[Code, Feedback]]) -> Dict[str, set[int]]:
        used: Dict[str, set[int]] = defaultdict(set)
        for guess, _ in history:
            for pos, ch in enumerate(guess):
                used[ch].add(pos)
        return used

    def choose(self, history: History, top_k: int = 15) -> Dict[str, object]:
        normalized = normalize_history(history)
        investigation = self.investigation_state(normalized)

        # Serve opening book without loading the matrix.
        if len(normalized) == 0:
            opening_action = self.classify_action(OPENING_FIRST, normalized, investigation, True)
            return {"phase": "opening_first", "investigation": investigation, "candidates": ALL_CODES, "recommendations":[{"guess": OPENING_FIRST, "score": 0.0, "is_candidate": True, "reason": "fixed first guess", "action": opening_action}]}
        if len(normalized) == 1 and normalized[0][0] == OPENING_FIRST:
            second = OPENING_SECOND_BY_FEEDBACK.get(normalized[0][1])
            if second is not None:
                second_action = self.classify_action(second, normalized, investigation, False)
                return {"phase": "opening_second", "investigation": investigation, "candidates": [], "recommendations":[{"guess": second, "score": 0.0, "is_candidate": False, "reason": "opening book: stable AVG second move", "action": second_action}]}

        candidates = self.filter_candidates(normalized)
        if not candidates:
            investigation["task_status"] = "state_inconsistent"
            return {
                "phase": "inconsistent",
                "investigation": investigation,
                "candidates": [],
                "recommendations": [],
                "raw_recommendations": [],
                "task_eligible_count": 0,
            }
        phase = self.game_phase(normalized, candidates)
        stats = self.stats(candidates)
        n = stats["n"]
        weights, main_candidates = self.candidate_weights(candidates, stats)
        candidate_set = set(candidates)
        used = self.used_positions(normalized)
        avg_index, avg_exp, avg_max, avg_bucket_count = self.best_pure_guess(candidates, "avg")

        if phase == "endgame" and len(candidates) <= 10 and avg_max == 1:
            return {
                "phase": phase,
                "investigation": investigation,
                "candidates": [ALL_CODES[i] for i in candidates],
                "avg_anchor": {"guess": ALL_CODES[avg_index], "exp": avg_exp, "max": avg_max, "bucket_count": avg_bucket_count},
                "recommendations": [{"guess": ALL_CODES[avg_index], "score": avg_exp, "is_candidate": avg_index in candidate_set, "reason": "perfect endgame split", "action": self.classify_action(ALL_CODES[avg_index], normalized, investigation, avg_index in candidate_set)}],
            }

        policy = investigation["task_policy"]
        exp_limit = avg_exp * policy["expected_ratio"] + policy["expected_slack"]
        max_limit = avg_max * policy["max_ratio"] + policy["max_slack"]
        scored: List[Dict[str, object]] = []
        for guess_index, guess in enumerate(ALL_CODES):
            weighted_exp, weighted_max, bucket_count = self.weighted_stats(candidates, guess_index, weights)
            normal_exp, normal_max, _ = self.avg_remaining(candidates, guess_index)
            main_exp, _, _ = self.avg_remaining(main_candidates, guess_index)
            is_candidate = guess_index in candidate_set
            scored.append({
                "guess": guess,
                "is_candidate": is_candidate,
                "weighted_expected": weighted_exp,
                "normal_expected": normal_exp,
                "normal_max_bucket": normal_max,
                "main_world_expected": main_exp,
                "bucket_count": bucket_count,
            })
            scored[-1]["action"] = self.classify_action(guess, normalized, investigation, is_candidate)
        guarded = [
            x for x in scored
            if x["normal_expected"] <= exp_limit + 1e-9
            and x["normal_max_bucket"] <= max_limit
        ]
        task = investigation.get("task")
        structurally_eligible = [x for x in scored if self.action_is_eligible(x["action"], task)]
        task_eligible = [x for x in guarded if self.action_is_eligible(x["action"], task)]
        if task_eligible:
            guarded = task_eligible
            investigation["task_status"] = "ready"
        elif structurally_eligible:
            guarded = structurally_eligible
            investigation["task_status"] = "task_relaxable"
        else:
            guarded = scored
            investigation["task_status"] = "task_infeasible"
            investigation["next_task"] = self.task_transition(task)
        if all(x["guess"] != ALL_CODES[avg_index] for x in guarded) and not structurally_eligible:
            avg_item = next((x for x in scored if x["guess"] == ALL_CODES[avg_index]), None)
            if avg_item:
                guarded.append(avg_item)
        guarded.sort(key=lambda x: self.task_sort_key(x, investigation))
        action_summary = Counter(item["action"]["type"] for item in guarded)
        return {
            "phase": phase,
            "investigation": investigation,
            "candidates": [ALL_CODES[i] for i in candidates],
            "avg_anchor": {"guess": ALL_CODES[avg_index], "exp": avg_exp, "max": avg_max, "bucket_count": avg_bucket_count},
            "task_policy": policy,
            "action_summary": dict(action_summary),
            "task_eligible_count": len(task_eligible),
            "recommendations": guarded[:top_k],
            "raw_recommendations": guarded[:top_k],
        }

    def next_guess(self, history: History) -> Code:
        return self.choose(history, top_k=1)["recommendations"][0]["guess"]


    def play_answer(self, answer: Code, max_steps: int = 10) -> List[Tuple[Code, Feedback, int]]:
        answer = validate_code(answer)
        history: List[Tuple[Code, Feedback]] = []
        rows: List[Tuple[Code, Feedback, int]] = []
        for _ in range(max_steps):
            guess = self.next_guess(history)
            fb = self.feedback(answer, guess)
            history.append((guess, fb))
            remaining = len(self.filter_candidates(history))
            rows.append((guess, fb, remaining))
            if fb == (4, 0):
                break
        return rows



_DEFAULT_SOLVER: Optional[QuestLineSolver] = None

def get_default_solver(verbose: bool = False) -> QuestLineSolver:
    global _DEFAULT_SOLVER
    if _DEFAULT_SOLVER is None:
        _DEFAULT_SOLVER = QuestLineSolver(verbose=verbose)
    elif verbose:
        _DEFAULT_SOLVER.verbose = True
    return _DEFAULT_SOLVER


def choose_questline_guess(history: History, top_k: int = 15) -> Dict[str, object]:
    return get_default_solver().choose(history, top_k=top_k)


def choose_human_like_guess(history: History, top_k: int = 15) -> Dict[str, object]:
    """Backward-compatible alias."""
    return choose_questline_guess(history, top_k=top_k)


def print_report(history: History, top_k: int = 15) -> None:
    result = get_default_solver(verbose=True).choose(history, top_k=top_k)
    print("=" * 80)
    print("History:")
    normalized = normalize_history(history)
    if not normalized:
        print("  <empty>")
    else:
        for guess, fb in normalized:
            print(f"  {guess} -> {fb_to_str(fb)}")
    print()
    print(f"Phase: {result.get('phase')}")
    if result.get("candidates"):
        print(f"Candidates: {len(result['candidates'])}")
    anchor = result.get("avg_anchor")
    if anchor:
        print(f"AVG anchor: {anchor['guess']} exp={anchor['exp']:.3f}, max={anchor['max']}, buckets={anchor['bucket_count']}")
    print()
    print("QuestLine recommendations:")
    for i, rec in enumerate(result["recommendations"], 1):
        if isinstance(rec, dict):
            reason = rec.get("reason")
            if reason:
                print(f"{i:2d}. {rec['guess']}  {reason}")
            else:
                print(f"{i:2d}. {rec['guess']} AVG={rec['normal_expected']:.3f} max={rec['normal_max_bucket']}")
    print("=" * 80)


def interactive() -> None:
    print("QuestLine")
    print("A narrative-driven Bulls & Cows solver.")
    print("Feedback examples: 0b1c, 1b2c, 1a2b, 1,2, 12")
    print("Commands: q/quit/exit, undo, history, report, help")
    history: List[Tuple[Code, Feedback]] = []
    solver = get_default_solver(verbose=False)
    while True:
        guess = solver.next_guess(history)
        print()
        print(f"Round {len(history) + 1}")
        print(f"Next guess: {guess}")
        text = input("Feedback: ").strip()
        lower = text.lower()
        if lower in {"q", "quit", "exit"}:
            break
        if lower in {"undo", "back"}:
            if history:
                removed = history.pop()
                print(f"Removed: {removed[0]} -> {fb_to_str(removed[1])}")
            else:
                print("History is already empty.")
            continue
        if lower in {"h", "history"}:
            if not history:
                print("History is empty.")
            else:
                for g, fb in history:
                    print(f"  {g} -> {fb_to_str(fb)}")
            continue
        if lower in {"r", "report"}:
            print_report(history)
            continue
        if lower in {"help", "?"}:
            print("Feedback examples: 0b1c, 1b2c, 1a2b, 1,2, 12")
            print("Commands: q/quit/exit, undo, history, report, help")
            continue
        try:
            fb = parse_feedback(text)
        except Exception as exc:
            print(f"Input error: {exc}")
            continue
        history.append((guess, fb))
        if fb == (4, 0):
            print("Solved!")
            break


def build_cache() -> None:
    solver = QuestLineSolver(verbose=True)
    solver.ensure_matrix()
    print("Cache ready.")


def main(argv: Optional[Sequence[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="QuestLine Bulls & Cows solver")
    parser.add_argument("--demo", action="store_true", help="show a fixed report demo")
    parser.add_argument("--build-cache", action="store_true", help="build feedback matrix cache and exit")
    args = parser.parse_args(argv)
    if args.build_cache:
        build_cache()
        return
    if args.demo:
        print_report([("0123", "0b1c"), ("1045", "0b1c")])
        return
    interactive()


if __name__ == "__main__":
    main()
